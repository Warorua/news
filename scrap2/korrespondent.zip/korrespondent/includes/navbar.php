<div class="container">
    <ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="ajax_trending.php">Trending</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="ajax_search.php">Search</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Link</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled">Disabled</a>
  </li>
</ul>
    </div>
</br>